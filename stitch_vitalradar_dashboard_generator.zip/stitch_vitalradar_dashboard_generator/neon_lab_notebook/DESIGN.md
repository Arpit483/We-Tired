---
name: Neon Lab Notebook
colors:
  surface: '#141218'
  surface-dim: '#141218'
  surface-bright: '#3b383e'
  surface-container-lowest: '#0f0d13'
  surface-container-low: '#1d1b20'
  surface-container: '#211f24'
  surface-container-high: '#2b292f'
  surface-container-highest: '#36343a'
  on-surface: '#e6e0e9'
  on-surface-variant: '#cbc4d2'
  inverse-surface: '#e6e0e9'
  inverse-on-surface: '#322f35'
  outline: '#948e9c'
  outline-variant: '#494551'
  surface-tint: '#cfbcff'
  primary: '#cfbcff'
  on-primary: '#381e72'
  primary-container: '#6750a4'
  on-primary-container: '#e0d2ff'
  inverse-primary: '#6750a4'
  secondary: '#cdc0e9'
  on-secondary: '#342b4b'
  secondary-container: '#4d4465'
  on-secondary-container: '#bfb2da'
  tertiary: '#e7c365'
  on-tertiary: '#3e2e00'
  tertiary-container: '#c9a74d'
  on-tertiary-container: '#503d00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#cfbcff'
  on-primary-fixed: '#22005d'
  on-primary-fixed-variant: '#4f378a'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#cdc0e9'
  on-secondary-fixed: '#1f1635'
  on-secondary-fixed-variant: '#4b4263'
  tertiary-fixed: '#ffdf93'
  tertiary-fixed-dim: '#e7c365'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#594400'
  background: '#141218'
  on-background: '#e6e0e9'
  surface-variant: '#36343a'
typography:
  display-xl:
    fontFamily: Syne
    fontSize: 80px
    fontWeight: '800'
    lineHeight: 72px
    letterSpacing: -0.04em
  h1:
    fontFamily: Syne
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  h2:
    fontFamily: Syne
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 32px
  data-lg:
    fontFamily: IBM Plex Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 24px
  data-md:
    fontFamily: IBM Plex Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 20px
  body-reg:
    fontFamily: IBM Plex Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: IBM Plex Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 12px
  code-sm:
    fontFamily: IBM Plex Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 12px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  gutter: 16px
  margin: 24px
---

## Brand & Style

The design system is built on the intersection of scientific precision and the raw energy of an 80s terminal. It subverts traditional medical UI by adopting a "Lab Notebook" aesthetic—scrappy, high-contrast, and deeply functional. The emotional response is one of immediate clarity and technical authority, flavored with the rebellious spirit of data journalism.

The aesthetic rejects modern polish in favor of "Neon Brutalism." It treats data as the primary decorative element. Every interaction should feel like a definitive entry in a digital logbook. There is no room for ambiguity; information is either present or absent, signaled through harsh color blocks and razor-sharp structural lines.

## Colors

The palette is anchored by a deep charcoal background that allows neon data points to "glow" through contrast rather than luminescence. The two primary sensor colors—Lime and Coral—are used to differentiate data streams instantly. 

- **Lime (#AAFF00)**: Reserved for Sensor 1 primary metrics and "Go" states.
- **Coral (#FF5C5C)**: Reserved for Sensor 2 primary metrics and "Stop" states.
- **Cyan (#00E5FF)**: Used for UI navigation, active selection, and secondary metadata.
- **Amber (#FFB800)**: Strictly for cautionary data thresholds and non-critical alerts.
- **Off-white (#F0EDE6)**: Used for all primary reading text to reduce eye strain compared to pure white.

## Typography

This design system utilizes a high-contrast typographic pairing. **Syne** provides a heavy, aggressive display presence for headings and primary metrics, grounding the UI in a bold, editorial feel. 

**IBM Plex Mono** is used for all functional data, body copy, and labels. This reinforces the "terminal" aesthetic and ensures that numerical data is perfectly aligned and legible. All labels should prioritize uppercase or monospaced formatting to maintain the laboratory logbook feel. Headlines should have tight leading to create dense, impactful blocks of text.

## Layout & Spacing

The layout is a rigid 12-column grid that mimics a technical schematic. Every element must align to a 4px baseline rhythm. Instead of using whitespace for separation, this design system uses 1px solid borders to box in content, creating a "bento box" or "ledger" appearance.

Containers should be packed tightly to maximize information density. Use the `md (16px)` gutter for standard separation between data modules. In mobile views, the grid collapses to a single column, but the 1px borders must remain to define the edges of the data fields.

## Elevation & Depth

This design system is strictly flat. It completely avoids shadows, blurs, and z-axis depth. Hierarchy is established through:

1.  **Border Color**: Active or critical modules use the Primary Lime or Coral 1px borders; inactive modules use a dimmed version of the text color.
2.  **Solid Fills**: Use solid blocks of color (#AAFF00 or #FF5C5C) for active states or primary buttons.
3.  **Texture (ASCII)**: Depth and "shadow" effects are achieved through text symbols like `▓` (dark shade) and `░` (light shade) to create a sense of texture without breaking the 2D plane.
4.  **Inversion**: Selected items should invert (Off-white background with #141414 text).

## Shapes

The shape language is binary: everything is a rectangle. There are no rounded corners (0px radius) in this design system. This applies to buttons, cards, input fields, and even selection indicators. 

Sharp corners reinforce the mathematical and technical nature of breathing detection. Borders are always a consistent 1px width. When nesting boxes, ensure the borders align perfectly to the grid to maintain a clean, architectural look.

## Components

### Buttons
Buttons are solid rectangles. **Primary Action:** Solid Lime (#AAFF00) with Black (#141414) text. **Secondary:** 1px Cyan border with Cyan text. **Hover/Active:** Invert the colors or add a `→` symbol to the end of the text label.

### Data Chips
Small, 1px bordered boxes containing monospaced text. Use the symbol `●` before the text to indicate a "live" status or `◎` for standby.

### Text Symbols (Iconography)
Do not use SVG icon packs. Use specific UTF-8 symbols for all metaphors:
- **Close:** `✕`
- **Navigation:** `→`, `←`, `↑`, `↓`
- **Status:** `●` (Active), `○` (Inactive)
- **Loading:** `▓▒░` (Animated progress strings)
- **Settings:** `[=]`

### Cards / Data Modules
Every data module must have a header bar separated by a 1px line. The header should contain a label in `label-caps` and a symbol indicating the sensor source (e.g., `[ S1 ]`).

### Input Fields
Inputs are simple 1px Cyan borders. When focused, the border remains Cyan, but the background fills with a 10% Cyan opacity, and the cursor is a solid `█` block.

### Lists
Lists are separated by 1px horizontal lines only. Each item starts with a `|` character or a `→` to denote the row entry.